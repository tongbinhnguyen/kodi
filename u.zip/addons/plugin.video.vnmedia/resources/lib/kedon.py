from urllib.parse import urlparse,quote,unquote,quote_plus,urlencode
from requests.packages.urllib3.util import connection
from codequick import Resolver,Listitem,Script
from requests import Session
from bs4 import BeautifulSoup
from collections import OrderedDict
from urlquick import get,post,cache_cleanup
from xbmc import executebuiltin
from xbmcvfs import translatePath
from cloudscraper import create_scraper
from base64 import b64encode
from json import loads,dumps
from random import randint
from time import time, localtime
from shutil import rmtree
from resolveurl import resolve
from codequick.utils import italic
from datetime import datetime, timedelta
from html import unescape
import re,sys,os
connection.HAS_IPV6 = False
__addonname__ = Script.get_info('name')
__version__ = Script.get_info('version')
__icon__ = Script.get_info('icon')
__addonnoti__ = f'{__addonname__} v{__version__}'
veruser = randint(250000, 999999)
verchr = f'128.{".".join(str(randint(0, 9999)) for _ in range(3))}'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'),'plugin.video.vnmedia')
userpix = f'(Linux; Android 14; Pixel 8 Pro Build/AP1A.{veruser})'
userios = f'AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/{verchr}'
useragentdf = f'Mozilla/5.0 {userpix} {userios} Mobile Safari/605.1.15 EdgA/{verchr}'
useragentweb = f'Mozilla/5.0 (Windows NT 10.0; Win64; x64) {userios} Safari/605.1.15 Edg/{verchr}'
useragentott = f'OTT Navigator/1.7.1.4 {userpix} ExoPlayerLib/2.19.1'
userfs = 'FshareiOSApp-saCP7ssw2u7w'
keyfs = 'MkywVt2UBRHcJXUUcfsZ7XXzBSJV3dwE'
news = 'https://raw.githubusercontent.com/kenvnm/kvn/main/qc.as'
qc = 'https://m.youtube.com/watch?v=dertW1A0MsE'
headersnct = {'x-nct-token': 'eyJhbGciOiJIUzI1NiJ9.eyJsb2dpbk1ldGhvZCI6IjUiLCJleHAiOjE2ODMyMDYyNzEsImV4cGlyZWREYXRlIjoiMCIsIm5iZiI6MTY4MDYxNDI3MSwiZGV2aWNlaW5mbyI6IntcIkRldmljZUlEXCI6XCIzQjBGNDUyNUJDOEQ0NUI0QUQxNjZDNzdBMDQ1NjlFNlwiLFwiT3NOYW1lXCI6XCJBTkRST0lEXCIsXCJPc1ZlcnNpb25cIjpcIjIyXCIsXCJBcHBOYW1lXCI6XCJOQ1RNb2JpbGVcIixcIkFwcFZlcnNpb25cIjpcIjguMS4yXCIsXCJVc2VyTmFtZVwiOlwiXCIsXCJQcm92aWRlclwiOlwiTkNUQ29ycFwiLFwiRGV2aWNlTmFtZVwiOlwiQVNVU19aMDFRRFwiLFwiUXVhbGl0eVBsYXlcIjpcIlwiLFwiUXVhbGl0eURvd25sb2FkXCI6XCJcIixcIlF1YWxpdHlDbG91ZFwiOlwiXCIsXCJOZXR3b3JrXCI6XCJXSUZJXCIsXCJRdWFsaXR5TVZQbGF5XCI6XCJcIixcIlF1YWxpdHlNVkRvd25sb2FkXCI6XCJcIixcIkFkSURcIjpcIlwiLFwiRGV2aWNlVHlwZVwiOlwiU01BUlRfUEhPTkVcIixcImlzVk5cIjp0cnVlfSIsImlhdCI6MTY4MDYxNDI3MSwiZGV2aWNlSWQiOiIzQjBGNDUyNUJDOEQ0NUI0QUQxNjZDNzdBMDQ1NjlFNiJ9.4GAMSL6i72oG52XlpLo0VckBEe37bKjqR5jIuSqSqoo',
'user-agent':'okhttp/4.12.0',
'x-nct-deviceid': '3B0F4525BC8D45B4AD166C77A04569E6',
'x-nct-version':'8.1.2',
'x-nct-language':'vi',
'x-nct-uuid':'a48d89a4d33e9a3c',
'x-nct-checksum':'ab6eb574836879df6bcb204ea3e3e655121521cfbf21a8959edbd9136d13bd30',
'x-nct-userid':'33007211',
'x-nct-os':'android',
'accept-encoding':'gzip'}
u90 = 'http://bit.ly/tiengruoi'
def urlfix(url):
	cleaned_location = '%20'.join(url.strip().split())
	return re.sub(r':(\/+)', r'://', cleaned_location)
def ace(kenh, tenkenh):
	if 'acestream' in kenh:
		tach = kenh.split('//')
		p = tach[1]
	else:
		p = re.search(r'id=(.*?)&', kenh)[1] if '&' in kenh else kenh.split('id=')[1]
	kenhace = ''.join(("{'label': '", tenkenh.strip(),"', 'action': 'play', 'fanart': '', 'icon': '', 'id': '", p.strip(), "'}"))
	return f"plugin://script.module.horus/?{quote(b64encode(kenhace.encode('utf-8')).decode('utf-8'))}"
def fu(url):
	with Session() as s:
		try:
			r = s.get(url, timeout=20, allow_redirects=False)
		except:
			r = s.get(url, timeout=20, verify=False, allow_redirects=False)
	try:
		return urlfix(r.headers['Location'])
	except:
		return r.url
def getlink(url, ref, luu):
	try:
		r = get(url, timeout=20, max_age=luu, headers={'user-agent': useragentdf,'referer': ref.encode('utf-8')})
	except:
		r = get(url, timeout=20, max_age=luu, headers={'user-agent': useragentdf,'referer': ref.encode('utf-8')}, verify=False)
	if 'cloudfare' in r.text.lower() and 'script' in r.text.lower():
		scraper = create_scraper(delay=20, disableCloudflareV1=True, browser={'browser':'chrome','platform':'windows','mobile':False})
		rcf = scraper.get(url,headers={'Referer': url})
		rcf.encoding = 'utf-8'
		return rcf
	else:
		r.encoding = 'utf-8'
		return r
def getlinkss(url, bien):
	with Session() as s:
		try:
			r = s.get(url, timeout=20, headers=bien)
		except:
			r = s.get(url, timeout=20, headers=bien, verify=False)
	r.encoding = 'utf-8'
	return r
def getlinkweb(url, ref, luu):
	try:
		r = get(url, timeout=20, max_age=luu, headers={'sec-fetch-site': 'same-origin','user-agent': useragentweb,'referer': ref.encode('utf-8')})
	except:
		r = get(url, timeout=20, max_age=luu, headers={'sec-fetch-site': 'same-origin','user-agent': useragentweb,'referer': ref.encode('utf-8')}, verify=False)
	if 'cloudfare' in r.text.lower() and 'script' in r.text.lower():
		scraper = create_scraper(delay=20, disableCloudflareV1=True, browser={'browser':'chrome','platform':'windows','mobile':False})
		rcf = scraper.get(url,headers={'Referer': url})
		rcf.encoding = 'utf-8'
		return rcf
	else:
		r.encoding = 'utf-8'
		return r
def getlinkphongblack(urlvmf, ref, luu):
	try:
		r = get(urlvmf, timeout=20, max_age=luu, headers={'user-agent': f'{useragentweb} VietMedia/1.0','referer': ref.encode('utf-8')})
	except:
		r = get(urlvmf, timeout=20, max_age=luu, headers={'user-agent': f'{useragentweb} VietMedia/1.0','referer': ref.encode('utf-8')}, verify=False)
	r.encoding = 'utf-8'
	return r
def getlinkip(url, ref):
	url = fu(url)
	return getlinkss(url, {'user-agent': useragentott,'accept-encoding':'gzip','referer': ref.encode('utf-8')})
def postlinktimfs(url, ref, luu):
	try:
		r = post(url, timeout=20, max_age=luu, headers={'user-agent': useragentdf, 'referer': ref.encode('utf-8'), 'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoiZnNoYXJlIiwidXVpZCI6IjcxZjU1NjFkMTUiLCJ0eXBlIjoicGFydG5lciIsImV4cGlyZXMiOjAsImV4cGlyZSI6MH0.WBWRKbFf7nJ7gDn1rOgENh1_doPc07MNsKwiKCJg40U'})
	except:
		r = post(url, timeout=20, max_age=luu, headers={'user-agent': useragentdf, 'referer': ref.encode('utf-8'), 'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoiZnNoYXJlIiwidXVpZCI6IjcxZjU1NjFkMTUiLCJ0eXBlIjoicGFydG5lciIsImV4cGlyZXMiOjAsImV4cGlyZSI6MH0.WBWRKbFf7nJ7gDn1rOgENh1_doPc07MNsKwiKCJg40U'}, verify=False)
	r.encoding = 'utf-8'
	return r
def stream(url):
	c = unescape((urlfix(url)))
	return f'{c}&User-Agent={useragentdf}' if '|' in url else f'{c}|User-Agent={useragentdf}'
def streamiptv(url, user):
	b = f'User-Agent={user.strip()}'
	c = '%20'.join(url.strip().split())
	return f'{unescape(c)}&{b}' if '|' in url else f'{unescape(c)}|{b}'
def referer(url):
	parsed_url = urlparse(url.strip())
	referer_base = f'{parsed_url.scheme}://{parsed_url.netloc}'
	ref = f'&Origin={referer_base}&Referer={referer_base}/&verifypeer=false'
	return ref
def replace_all(dict, str):
	pattern = re.compile('|'.join(re.escape(key) for key in dict.keys()))
	return pattern.sub(lambda match: dict[match.group()], str)
def get_file_path(filename):
	return os.path.join(addon_data_dir, filename)
def has_file_path(filename):
	return os.path.exists(get_file_path(filename))
def get_last_modified_time_file(filename):
	return int(os.path.getmtime(get_file_path(filename)))
def remove_file(filename):
	if has_file_path(filename):
		os.remove(get_file_path(filename))
def remove_folder(path):
	try:
		rmtree(path, ignore_errors=True, onerror=None)
	except:
		return False
def write_file(name, content, binary=False):
	if not os.path.exists(addon_data_dir):
		os.makedirs(addon_data_dir)
	path = get_file_path(name)
	try:
		write_mode = 'wb+' if binary else 'w+'
		f = open(path, mode=write_mode)
		f.write(content)
		f.close()
	except:
		pass
	return path
def read_file(name, binary=False):
	content = None
	read_mode = 'rb' if binary else 'r'
	try:
		path = get_file_path(name)
		f = open(path, mode=read_mode)
		content = f.read()
		f.close()
	except:
		pass
	return content
def ttfs(x):
	try:
		idfd = re.search(r'(file|folder)/([A-Z0-9]+)', x)[2]
		ufs = f'https://www.fshare.vn/api/v3/files/folder?linkcode={idfd}&sort=type%2Cname&page=1&per-page=50'
		r = getlinkss(ufs, {'user-agent':useragentdf,'origin':x,'referer':x})
		return r
	except:
		cache_cleanup(-1)
		remove_file('.urlquick.slite3')
		sys.exit()
def get_info_fs(x):
	try:
		r = ttfs(x)
		if 'current' in r.text:
			l = r.json()['current']
			return (l['name'], l['size'])
		else:
			pass
	except:
		return None
def userpassfs():
	username = Script.setting.get_string('username')
	password = Script.setting.get_string('password')
	if username and password:
		payload = {'user_email':username,'password':password,'app_key':keyfs}
		head = {'user-agent':userfs, 'content-type': 'application/json; charset=utf-8'}
		try:
			try:
				response = post('https://api.fshare.vn/api/user/login',data=dumps(payload),headers=head,timeout=20,max_age=7200)
			except:
				response = post('https://api.fshare.vn/api/user/login',data=dumps(payload),headers=head,timeout=20,max_age=7200, verify=False)
			headerfsvn = {'user-agent':userfs, 'cookie' : f"session_id={response.json()['session_id']}"}
			r = getlinkss('https://api.fshare.vn/api/user/get', headerfsvn)
			if r.status_code == 200:
				return (response.json()['token'], response.json()['session_id'])
			else:
				cache_cleanup(-1)
				remove_file('.urlquick.slite3')
				userpassfs()
		except:
			cache_cleanup(-1)
			remove_file('.urlquick.slite3')
			Script.notify(__addonnoti__, 'Đăng nhập thất bại')
			sys.exit()
	else:
		Script.notify(__addonnoti__, 'Vui lòng nhập tài khoản Fshare trong cài đặt của VN Media')
		sys.exit()
def getfs(x):
	try:
		j = userpassfs()
		payload = {'zipflag':0, 'url':x, 'password':'', 'token': j[0]}
		headerfsvn = {'user-agent':userfs, 'cookie' : f'session_id={j[1]}', 'content-type': 'application/json; charset=utf-8'}
		with Session() as s:
			try:
				uf = s.post('https://api.fshare.vn/api/session/download', timeout=20,data=dumps(payload),headers=headerfsvn)
			except:
				uf = s.post('https://api.fshare.vn/api/session/download', timeout=20,data=dumps(payload),headers=headerfsvn, verify=False)
		if 'location' in uf.text:
			return uf.json()['location']
		else:
			Script.notify(__addonnoti__, uf.json()['msg'])
			sys.exit()
	except:
		sys.exit()
def basicfs(x):
	try:
		j = userpassfs()
		idfd = re.search(r'(file|folder)/([A-Z0-9]+)', x)[2]
		payload = {'token': j[0], 'linkcode':idfd}
		headerfsvn = {'user-agent':userfs, 'cookie' : f'session_id={j[1]}', 'content-type': 'application/json; charset=utf-8'}
		with Session() as s:
			try:
				uf = s.post('https://api.fshare.vn/api/fileops/getBasicInfo', timeout=20, data=dumps(payload), headers=headerfsvn)
			except:
				uf = s.post('https://api.fshare.vn/api/fileops/getBasicInfo', timeout=20, data=dumps(payload), headers=headerfsvn, verify=False)
			return uf.json()['name']
	except:
		return 'Lỗi đăng nhập'
def getrow(row):
	return row['v'] if (row is not None) and (row['v'] is not None) else ''
def subdmtodm(url):
	r = getlink(f'{url}/bc/js/custom.js',url,-1).text
	match = re.search(r"url\s*:\s*'([^']+)'", r)[1]
	v = urlparse(match)
	bc = f'{v.scheme}://{v.netloc}'
	return bc
def quangcao():
	now = localtime()
	i = Listitem()
	i.label = 'Đang cập nhật. Hãy dành thời gian này cho gia đình và trở lại sau ít phút nữa nhé!'
	i.info['mediatype'] = 'episode'
	i.art['thumb'] = i.art['poster'] = f'https://www.xemlicham.com/images/ngay/lich-am-ngay-{now.tm_mday}-thang-{now.tm_mon}-nam-{now.tm_year}.png'
	i.path = qc
	return i
def ggdich(tk):
	r = getlink(f'https://translate.googleapis.com/translate_a/single?ie=UTF-8&oe=UTF-8&client=gtx&sl=en&tl=vi&dt=t&q={tk}', 'https://translate.google.com/', 1000)
	return r.json()[0][0][0]
def respphut90():
	tr = 'https://vebo.tv'
	resp90 = getlink(tr, tr,-1)
	if (resp90 is not None):
		html_content = re.sub(r"(\n\s*//.*)", "", resp90.text)
		ref = re.search(r'base_embed_url.*?("|\')([^"\s]+)("|\')', html_content)[2]
	else:
		ref = tr
	return ref
def get_list(idk):
	url = f'http://api.thapcam.xyz/api/match/{idk}/meta'
	resp = getlink(url, url,-1)
	return resp
def yttk(tk):
	tim = re.sub(r"[\W_]+"," ", tk)
	return f'plugin://plugin.video.vnmedia/resources/lib/mkd/onyoutube/tim/trailer_youtube/?search_query={tim}'
def search_history_save(search_key):
	if not search_key:
		return
	content = read_file('historys.json')
	content = loads(content) if content else []
	idx = next((content.index(i) for i in content if search_key == i), -1)
	if (idx >= 0) and (len(content) > 0):
		del content[idx]
	elif len(content) >= 20:
		content.pop()
	content.insert(0, search_key)
	write_file('historys.json', dumps(content))
def search_history_clear():
	write_file('historys.json', dumps([]))
def search_history_get():
	content = read_file('historys.json')
	content = loads(content) if content else []
	return content
def save_last_watch_movie(data):
	if not data:
		return
	content = read_file('watcheds.json')
	content = loads(content, object_pairs_hook=OrderedDict) if content else OrderedDict()
	cache_id, query = data
	content.update({cache_id: query})
	content.move_to_end(cache_id, last=False)
	while len(content) > int(Script.setting.get_string('historyfs')):
		content.popitem(last=True)
	write_file('watcheds.json', dumps(content))
def get_last_watch_movie():
	content = read_file('watcheds.json')
	content = loads(content) if content else {}
	return content
def save_last_watch_play(data):
	if not data:
		return
	content = read_file('played.json')
	content = loads(content, object_pairs_hook=OrderedDict) if content else OrderedDict()
	cache_id, query = data
	content.update({cache_id: query})
	content.move_to_end(cache_id, last=False)
	while len(content) > int(Script.setting.get_string('historyfs')):
		content.popitem(last=True)
	write_file('played.json', dumps(content))
def get_last_play():
	content = read_file('played.json')
	content = loads(content) if content else {}
	return content
def gioithieu(title, mota, anh):
	item = Listitem()
	item.label = f'TRAILER: {italic(title)}'
	item.info['mediatype'] = 'episode'
	item.info['plot'] = mota
	item.art['thumb'] = item.art['poster'] = anh
	item.set_callback(Resolver.ref('/resources/lib/mkd/onyoutube/tim:trailer_youtube'), title)
	return item
def gmt7(time_str):
	try:
		time_obj = datetime.strptime(time_str, '%H:%M')
		gmp = time_obj + timedelta(hours=7)
		return gmp.strftime('%H:%M')
	except:
		return time_str
@Script.register
def remove_search_watch_movie(plugin, search_key):
	content = read_file('watcheds.json')
	content = loads(content, object_pairs_hook=OrderedDict) if content else OrderedDict()
	if search_key in content:
		del content[search_key]
		write_file('watcheds.json', dumps(content))
	executebuiltin('Container.Refresh()')
@Script.register
def remove_last_played(plugin, search_key):
	content = read_file('played.json')
	content = loads(content, object_pairs_hook=OrderedDict) if content else OrderedDict()
	if search_key in content:
		del content[search_key]
		write_file('played.json', dumps(content))
	executebuiltin('Container.Refresh()')
@Script.register
def remove_search_history(plugin, search_key):
	content = read_file('historys.json')
	content = loads(content) if content else []
	if search_key in content:
		content.remove(search_key)
		write_file('historys.json', dumps(content))
	executebuiltin('Container.Refresh()')
@Script.register
def search_history_clear(plugin):
	write_file('historys.json', dumps([]))
	executebuiltin('Container.Refresh()')
@Script.register
def clear_last_watch_movie(plugin):
	write_file('watcheds.json', '')
	executebuiltin('Container.Refresh()')
@Script.register
def clear_last_played(plugin):
	write_file('played.json', '')
	executebuiltin('Container.Refresh()')
@Script.register
def showimg(plugin, url):
    image_url = f"https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={url}&qzone=1&margin=1&size=720x720&ecc=L"
    executebuiltin(f'ShowPicture(\"{image_url}\")')
def yeucau(url):
	i = Listitem()
	i.label = 'Yêu cầu phim'
	i.art['thumb'] = i.art['poster'] = 'https://raw.githubusercontent.com/kenvnm/kvn/main/yeucauphim.png'
	i.set_callback(showimg, quote(url))
	return i
def listhls(x, y, a, b):
	uplay = a.strip()[6:]
	if any((re.search(r':(?!/)', uplay), ('?' in uplay))):
		i = Listitem()
		i.label = x
		i.path = f'{a}|{b}'
		i.subtitles = [y.strip()]
		return i
	else:
		i = Listitem()
		i.label = x
		i.path = a.strip()
		i.subtitles = [y.strip()]
		i.property['inputstream'] = 'inputstream.adaptive'
		i.property['inputstream.adaptive.manifest_type'] = 'hls'
		i.property['inputstream.adaptive.stream_headers'] = i.property['inputstream.adaptive.manifest_headers'] = b.strip()
		return i
def listqc(x, y, qc):
	i = Listitem()
	i.label = x
	i.path = qc.strip()
	i.subtitles = [y.strip()]
	return i
@Resolver.register
def play_vnm(plugin, url, title):
	save_last_watch_play((title, url))
	uplay = url[6:]
	if 'm3u8' in uplay:
		if any((re.search(r':(?!/)', uplay), ('?' in uplay))):
			return listqc(title, news, f'{url}|User-Agent={useragentdf}')
		elif '|' in uplay:
			d = url.split('|')
			return listhls(title, news, d[0], d[1])
		else:
			return listhls(title, news, url, f'User-Agent={useragentdf}')
	else:
		return listqc(title, news, url)
@Resolver.register
def ifr_bongda(plugin, url, title):
	resp = getlink(url, url, -1)
	if (resp is not None) and ('allowfullscreen' in resp.text):
		m = urlparse(url)
		linkweb = f'{m.scheme}://{m.netloc}'
		soup = BeautifulSoup(resp.text, 'html.parser')
		frame = soup.select_one('iframe[allowfullscreen]')['src']
		ifr = frame if 'http' in frame else f'{linkweb}{ifr}'
		r = getlink(ifr, url, -1)
		sre = re.compile(r'(https?://[^\s"]+\.m3u8[^"\']*)')
		if (r is not None) and ('m3u8' in r.text):
			linkstream = sre.search(r.text)[1]
			h = f'{stream(linkstream)}{referer(ifr)}'.split('|')
			return listhls(title, news, h[0], h[1])
		else:
			return listqc(title, news, qc)
	else:
		return listqc(title, news, qc)
@Resolver.register
def play_fs(plugin, url, title):
	if Script.setting.get_string('block_play_fs') == 'true':
		return listqc(title, news, qc)
	else:
		save_last_watch_movie((title, url))
		return listqc(title, news, getfs(url))
@Resolver.register
def playsocolive(plugin, numroom, timestamp, linkref, title):
	url = f'https://json.vnres.co/room/{numroom}/detail.json?v={timestamp}'
	r = getlink(url, url,-1)
	if r is not None:
		nd = re.search(r'(\{.*\})', r.text, re.DOTALL)[1]
		h = f"{stream(loads(nd)['data']['stream']['hdM3u8'])}{referer(linkref)}".split('|')
		return listhls(title, news, h[0], h[1])
	else:
		return listqc(title, news, qc)
@Resolver.register
def ifr_khomuc(plugin, url, title):
	r = getlinkweb(url, url, -1)
	if (r is not None) and ('m3u8' in r.text):
		match = re.search(r'(https?://[^\s"]+\.m3u8[^"\']*)', r.text)
		h = f'{stream(match[1])}{referer(url)}'.split('|')
		return listhls(title, news, h[0], h[1])
	else:
		return listqc(title, news, qc)
@Resolver.register
def play_vtvgo(plugin, timekenh, tokenkenh, idkenh, x, title):
	payload = {'type_id': '1','id': idkenh,'time': timekenh,'token': tokenkenh}
	headx = {'user-agent': useragentweb,
	'x-requested-with': 'XMLHttpRequest',
	'referer': f'https://vtvgo.vn/xem-truc-tuyen-kenh-vtv-{idkenh}.html',
	'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
	'sec-fetch-site': 'same-origin'}
	with Session() as s:
		try:
			p = s.post('https://vtvgo.vn/ajax-get-stream', timeout=20, data=urlencode(payload, quote_via=quote), cookies=x, headers=headx)
		except:
			p = s.post('https://vtvgo.vn/ajax-get-stream', timeout=20, data=urlencode(payload, quote_via=quote), cookies=x, headers=headx, verify=False)
	if (p is not None) and ('m3u8' in p.text):
		h = f'{stream(p.json()["chromecast_url"])}{referer("https://vtvgo.vn")}'.split('|')
		return listhls(title, news, h[0], h[1])
	else:
		return listqc(title, news, qc)
@Resolver.register
def play_xlvtvgo(plugin, idkenh, title):
	u = f'https://vtvgo.vn/ajax-get-epg-detail?epg_id={idkenh}&time={veruser}'
	p = getlinkweb(u, u, -1)
	if (p is not None) and ('data' in p.text):
		h = f'{stream(p.json()["data"])}{referer("https://vtvgo.vn")}'.split('|')
		return listhls(title, news, h[0], h[1])
	else:
		return listqc(title, news, qc)
@Resolver.register
def list_re90(plugin, url, ref, title):
	r = getlink(url, url, 1000)
	if (r is not None) and ('m3u8' in r.text):
		match = re.search(r'(https?://[^\s"]+\.m3u8[^"\']*)', r.text)
		if '=http' in match[1]:
			try:
				m = re.search(r'=(.*?)&', match[1])
				lp = unquote(m[1])
			except:
				m = match[1].split('=http')
				lp = unquote(f'http{m[1]}')
			h = f'{stream(lp)}{referer(ref)}'.split('|')
		else:
			h = f'{stream(match[1])}{referer(ref)}'.split('|')
		return listhls(title, news, h[0], h[1])
	else:
		return listqc(title, news, qc)
@Resolver.register
def playnct(plugin, url, title):
	idk = re.search(r'\.(\w+)\.html', url)
	if idk:
		r = getlinkss(f'https://graph.nhaccuatui.com/v7/songs/detail/{idk[1]}?iscloud=false&isDailyMix=false', headersnct)
		v= r.json()['data']['streamURL']
		d = qc if not r.json()['data']['streamURL'] else v[-1]['stream']
		return listqc(title, news, d)
	else:
		return listqc(title, news, qc)
@Resolver.register
def playvdnct(plugin, url, title):
	idk = re.search(r"(?<=\.)([\w-]+)(?=\.\w+$)", url)
	if idk:
		r = getlinkss(f'https://graph.nhaccuatui.com/v7/videos/detail/{idk[1]}?isFirst=false', headersnct)
		v= r.json()['data']['streamURL']
		d = qc if not r.json()['data']['streamURL'] else v[-1]['stream']
		return listqc(title, news, d)
	else:
		return listqc(title, news, qc)
@Resolver.register
def play123embed(plugin, url, title):
	try:
		if 'ajax' in url:
			r = getlink(url,url,-1).json()
		else:
			r1 = getlink(url,url,-1).text
			idk = re.search(r"loadSerieEpisode\('(.*?)'.*?'(.*?)'", r1)
			u2 = f'https://play.123embed.net/ajax/serie/get_sources/{idk[1]}/{idk[2]}/grab'
			r = getlink(u2, u2,-1).json()
		linkplay = loads(r['sources'])[0]['file']
		h = f'{stream(linkplay)}{referer(url)}'.split('|')
		sub = ''.join(k['file'] for k in loads(r['tracks']) if 'vietnam' in k['label'].lower())
		if 'http' in sub:
			return listhls(title, sub, h[0], h[1])
		else:
			return listhls(title, news, h[0], h[1])
	except:
		return listqc(title, news, qc)
@Resolver.register
def play_anime47(plugin, homeweb, idp, title):
	try:
		url = f'{homeweb}/player/player.php'
		headers = {'User-Agent': useragentdf,'X-Requested-With': 'XMLHttpRequest'}
		data = {'ID': idp, 'SV':'4', 'SV4':'4'}
		with Session() as s:
			try:
				response = s.post(url, timeout=20, headers=headers, data=data)
			except:
				response = s.post(url, timeout=20, headers=headers, data=data, verify=False)
		lp = re.search(r'"file".*?"(.*?)"', response.text)[1]
		h = f'{stream(lp)}{referer(homeweb)}'.split('|')
		if 'subtitles' in response.text:
			sub = re.findall(r'file:.*?"(.*?\.vtt)"', response.text)[-1]
			subfinal = f'{homeweb}{sub}' if sub.startswith('/') else sub
			return listhls(title, subfinal, h[0], h[1])
		else:
			return listhls(title, news, h[0], h[1])
	except:
		return listqc(title, news, qc)
@Resolver.register
def play_phimmoi(plugin, url, title, pm):
	try:
		r = getlink(url, url, -1)
		lp = re.search(r'data-link="(.*?)"', r.text)[1]
		linkplay = lp if lp.startswith('http') else f'{pm}{lp}'
		h = f'{stream(linkplay)}{referer(pm)}'.split('|')
		return listhls(title, news, h[0], h[1])
	except:
		return listqc(title, news, qc)
@Resolver.register
def play_bluphim(plugin, url, title, bl):
	try:
		url = url if url.startswith('http') else f'{bl}{url}'
		resp = getlink(url, url, -1)
		soup = BeautifulSoup(resp.text, 'html.parser')
		u = soup.select_one('iframe#iframeStream')['src']
		r = getlink(u, u, -1)
		try:
			match = re.search(r"var videoId.*?['|\"](.*?)['|\"].*?var subId.*?['|\"](.*?)['|\"].*?var web.*?['|\"](.*?)['|\"].*?var cdn.*?['|\"](.*?)['|\"].*?var lang.*?['|\"](.*?)['|\"]", r.text, re.DOTALL)
			u2 = f'https://cdn.cdnmoviking.tech/geturl?renderer=ANGLE%20(Intel,%20Intel(R)%20HD%20Graphics%20Direct3D11%20vs_5_0%20ps_5_0)&id=79b42d6abdc359ebb2f740a0ecb67c7f&videoId={match[1]}&domain={bl}/'
			r2 = getlink(u2, u2, -1)
			streaming_url = f"{match[4]}/streaming?id={match[1]}&subId={match[2]}&web={match[3]}&{r2.text}&cdn={match[4]}&lang={match[5]}"
			r3 = getlink(streaming_url, u2, -1)
			a = re.search(r"var url.*?['|\"](.*?)['|\"].*?['|\"](.*?)['|\"]", r3.text)
			linkplay = f'{a[1]}{match[1]}{a[2]}'
			h = f'{stream(linkplay)}{referer(streaming_url)}'.split('|')
			if 'vietnam' in r3.text.lower():
				sub = ''.join((k['file'] for k in loads(re.search(r'tracks:.*?(\[.*?\]),', r3.text)[1]) if 'vietnam' in k['label'].lower()))
				return listhls(title, sub, h[0], h[1])
			else:
				return listhls(title, news, h[0], h[1])
		except:
			u1 = re.search("embedIframe.*?=['|\"](.*?)['|\"]", r.text)[1]
			r2 = getlink(u1, u, -1)
			linkplay = re.search("var url.*?['|\"](.*?)['|\"]", r2.text)[1]
			h = f'{stream(linkplay)}{referer(linkplay)}'.split('|')
			return listhls(title, news, h[0], h[1])
	except:
		return listqc(title, news, qc)